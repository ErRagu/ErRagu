package numbersystem;

import java.util.Scanner;

public class opraters {

	public static void main(String[] args) {
		String hex,hex2;
		int a,b;
		System.out.println("Enter the Hex value : ");
		Scanner h=new Scanner(System.in);
		hex=h.next();
		System.out.println("Enter the Hex2 value : ");
		Scanner h2=new Scanner(System.in);
		hex2=h2.next();
		
		a=Integer.parseInt(hex, 16);
		System.out.println("the hex to dec : "+a);
		b=Integer.parseInt(hex2, 16);
		System.out.println("the hex to dec : "+b);
		//left shifter
		int c=a<<b;
		System.out.println("Left shift value : "+c);
		//Right shifter
		int d=a>>b;
		System.out.println("Right shift value : "+d);
		//And 
		int e=a&b;
		System.out.println("And oprater value is :"+e);
		//or
		int f=a|b;
		System.out.println("Or oprater value is :"+f);
	
	}

}
