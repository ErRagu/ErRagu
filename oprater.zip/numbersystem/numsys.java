package numbersystem;

import java.util.Scanner;

public class numsys {
//binary,octal,hex To decimal value
	public static void main(String[] args) {
		String bin,oct,hex;
		int dec;
		Scanner s =new Scanner(System.in);
	System.out.println("enter the bin no: ");
	bin=s.next();
	System.out.println("enter the oct no: ");
	oct=s.next();
	System.out.println("enter the hexa no: ");
	hex=s.next();
	
	dec=Integer.parseInt(bin, 2);
	System.out.println("the bin to dec : "+dec);
	dec=Integer.parseInt(oct, 8);
	System.out.println("the oct to dec : "+dec);
	dec=Integer.parseInt(hex, 16);
	System.out.println("the hex to dec : "+dec);
	}


}
