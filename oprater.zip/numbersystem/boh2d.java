package numbersystem;

import java.util.Scanner;

public class boh2d {

	//decimal To Binary,octal,hex
		public static void main(String[] args) {
			int dec;
			Scanner s1 =new Scanner(System.in);
			System.out.println("enter the decimal no : ");
		dec=s1.nextInt();
		String bin=Integer.toBinaryString(dec);
		System.out.println(" The Bin value: "+bin);
		String oct= Integer.toOctalString(dec);
		System.out.println("The Oct value: "+oct);
		String hex=Integer.toHexString(dec);
		System.out.println("The Hexa value: "+hex);
		}

}
