module json {
	requires java.json;
}