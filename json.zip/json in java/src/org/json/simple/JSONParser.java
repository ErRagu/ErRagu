package org.json.simple;

class JSONParser {

}
