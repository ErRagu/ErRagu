package org.json.simple;

public class JSONArray {

	public char[] toJSONString() {
		// TODO Auto-generated method stub
		return null;
	}

}
