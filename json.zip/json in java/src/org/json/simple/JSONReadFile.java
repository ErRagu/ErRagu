
package org.json.simple;
 
import org.json.JSONObject;
import org.json.simple.JSONArray;
import java.io.FileReader;
import java.util.Iterator;

public class JSONReadFile {
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("E:/output.json"));
			JSONObject jsonObject = (JSONObject) obj;
 			JSONArray companyList = (JSONArray) jsonObject.get("Emp List");
 
			Iterator<JSONObject> iterator = companyList.iterator();
			while (iterator.hasNext()) {
				System.out.println(iterator.next());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}